<footer>
    <img class="image" src="github.png">
    <img class="image" src="discord.png">
    <img class="image" src="x.png">
</footer>
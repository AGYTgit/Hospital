<header>
    <div class="header-left">
        <a href="index.php"><h2>Hospital</h></a>
    </div>
    <div class="header-mid">
        <a href="index.php"><h3>Patient</h3></a>
        <a href="index2.php"><h3>Staff</h3></a>
    </div>
    <div class="header-right">
        <a href="index3.php"><h3>Insert Patient</h3></a>
        <a href="index4.php"><h3>Insert Staff</h3></a>
    </div>
</header>